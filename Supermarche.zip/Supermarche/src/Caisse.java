
public class Caisse {

	/**
	 * tapis : le client d�pose les article un par un
	 */
	private int[] tapis = new int[Supermarche.TAILLE_TAPIS];

}
