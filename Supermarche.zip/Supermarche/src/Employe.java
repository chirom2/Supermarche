public class Employe extends Thread {
	public Tapis tapis;
	
	public Employe(Tapis tapis){
		this.tapis = tapis;
	}
	
	@Override
	public void run(){
		while(true){
			tapis.prendreArt();
		}
	}
}
